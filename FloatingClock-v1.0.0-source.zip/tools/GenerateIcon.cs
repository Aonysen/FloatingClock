using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

internal static class GenerateIcon
{
    private static readonly int[] Sizes = { 16, 20, 24, 32, 40, 48, 64, 128, 256 };

    private static void Main(string[] args)
    {
        string outputDirectory = args.Length > 0 ? args[0] : "assets";
        Directory.CreateDirectory(outputDirectory);

        using (Bitmap master = DrawIcon(512))
        {
            master.Save(Path.Combine(outputDirectory, "FloatingClock.png"), ImageFormat.Png);
            WriteIco(master, Path.Combine(outputDirectory, "FloatingClock.ico"));
        }
    }

    private static Bitmap DrawIcon(int size)
    {
        Bitmap bitmap = new Bitmap(size, size, PixelFormat.Format32bppArgb);
        using (Graphics graphics = Graphics.FromImage(bitmap))
        {
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            graphics.Clear(Color.Transparent);

            RectangleF tile = new RectangleF(size * 0.07f, size * 0.07f, size * 0.86f, size * 0.86f);
            using (GraphicsPath tilePath = RoundedRectangle(tile, size * 0.22f))
            using (LinearGradientBrush tileBrush = new LinearGradientBrush(tile,
                Color.FromArgb(255, 16, 105, 222), Color.FromArgb(255, 31, 196, 236), 45f))
            {
                graphics.FillPath(tileBrush, tilePath);
            }

            RectangleF face = new RectangleF(size * 0.21f, size * 0.19f, size * 0.58f, size * 0.58f);
            using (Brush faceBrush = new SolidBrush(Color.FromArgb(248, 252, 255)))
            using (Pen ring = new Pen(Color.FromArgb(48, 24, 63, 105), size * 0.018f))
            {
                graphics.FillEllipse(faceBrush, face);
                graphics.DrawEllipse(ring, face);
            }

            PointF center = new PointF(size * 0.50f, size * 0.48f);
            using (Pen hour = NewRoundPen(Color.FromArgb(255, 24, 54, 92), size * 0.045f))
            using (Pen minute = NewRoundPen(Color.FromArgb(255, 24, 54, 92), size * 0.037f))
            using (Brush hub = new SolidBrush(Color.FromArgb(255, 9, 66, 123)))
            {
                graphics.DrawLine(hour, center, new PointF(size * 0.38f, size * 0.39f));
                graphics.DrawLine(minute, center, new PointF(size * 0.62f, size * 0.33f));
                graphics.FillEllipse(hub, center.X - size * 0.035f, center.Y - size * 0.035f,
                    size * 0.07f, size * 0.07f);
            }

            using (GraphicsPath sparkle = new GraphicsPath())
            using (Brush sparkleBrush = new SolidBrush(Color.White))
            {
                float x = size * 0.76f;
                float y = size * 0.20f;
                float r = size * 0.075f;
                sparkle.AddPolygon(new[] {
                    new PointF(x, y - r), new PointF(x + r * 0.25f, y - r * 0.25f),
                    new PointF(x + r, y), new PointF(x + r * 0.25f, y + r * 0.25f),
                    new PointF(x, y + r), new PointF(x - r * 0.25f, y + r * 0.25f),
                    new PointF(x - r, y), new PointF(x - r * 0.25f, y - r * 0.25f)
                });
                graphics.FillPath(sparkleBrush, sparkle);
            }
        }
        return bitmap;
    }

    private static Pen NewRoundPen(Color color, float width)
    {
        Pen pen = new Pen(color, width);
        pen.StartCap = LineCap.Round;
        pen.EndCap = LineCap.Round;
        return pen;
    }

    private static GraphicsPath RoundedRectangle(RectangleF bounds, float radius)
    {
        GraphicsPath path = new GraphicsPath();
        float diameter = radius * 2f;
        RectangleF arc = new RectangleF(bounds.X, bounds.Y, diameter, diameter);
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }

    private static void WriteIco(Bitmap master, string path)
    {
        byte[][] images = new byte[Sizes.Length][];
        for (int index = 0; index < Sizes.Length; index++)
        {
            int size = Sizes[index];
            using (Bitmap scaled = new Bitmap(size, size, PixelFormat.Format32bppArgb))
            using (Graphics graphics = Graphics.FromImage(scaled))
            using (MemoryStream stream = new MemoryStream())
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.DrawImage(master, 0, 0, size, size);
                scaled.Save(stream, ImageFormat.Png);
                images[index] = stream.ToArray();
            }
        }

        using (BinaryWriter writer = new BinaryWriter(File.Create(path)))
        {
            writer.Write((ushort)0);
            writer.Write((ushort)1);
            writer.Write((ushort)Sizes.Length);
            int offset = 6 + 16 * Sizes.Length;
            for (int index = 0; index < Sizes.Length; index++)
            {
                int size = Sizes[index];
                writer.Write((byte)(size == 256 ? 0 : size));
                writer.Write((byte)(size == 256 ? 0 : size));
                writer.Write((byte)0);
                writer.Write((byte)0);
                writer.Write((ushort)1);
                writer.Write((ushort)32);
                writer.Write((uint)images[index].Length);
                writer.Write((uint)offset);
                offset += images[index].Length;
            }
            foreach (byte[] image in images) writer.Write(image);
        }
    }
}
