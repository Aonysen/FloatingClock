using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Serialization;
using Microsoft.Win32;

[assembly: AssemblyTitle("悬浮时钟")]
[assembly: AssemblyDescription("Windows 11 x64 悬浮时间显示工具")]
[assembly: AssemblyProduct("FloatingClock")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace FloatingClockApp
{
    [Serializable]
    public sealed class ClockSettings
    {
        public string FontName = "Microsoft YaHei UI";
        public float FontSize = 28f;
        public bool FontBold = true;
        public int TextColorArgb = Color.White.ToArgb();
        public int BackgroundColorArgb = Color.FromArgb(24, 24, 28).ToArgb();
        public int OpacityPercent = 82;
        public string TimeFormat = "HH:mm:ss";
        public bool AlwaysOnTop = true;
        public bool Locked = false;
        public bool ClickThrough = false;
        public bool RoundedCorners = true;
        public bool AutoStart = false;
        public int PositionX = -1;
        public int PositionY = -1;
    }

    internal static class SettingsStore
    {
        private static readonly string Folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FloatingClock");
        private static readonly string FilePath = Path.Combine(Folder, "settings.xml");

        public static ClockSettings Load()
        {
            try
            {
                if (!File.Exists(FilePath)) return new ClockSettings();
                using (FileStream stream = File.OpenRead(FilePath))
                {
                    return Normalize((ClockSettings)new XmlSerializer(typeof(ClockSettings)).Deserialize(stream));
                }
            }
            catch
            {
                return new ClockSettings();
            }
        }

        private static ClockSettings Normalize(ClockSettings settings)
        {
            if (settings == null) return new ClockSettings();
            if (String.IsNullOrWhiteSpace(settings.FontName)) settings.FontName = "Microsoft YaHei UI";
            settings.FontSize = Math.Max(8f, Math.Min(160f, settings.FontSize));
            settings.OpacityPercent = Math.Max(20, Math.Min(100, settings.OpacityPercent));
            if (String.IsNullOrWhiteSpace(settings.TimeFormat)) settings.TimeFormat = "HH:mm:ss";
            return settings;
        }

        public static void Save(ClockSettings settings)
        {
            try
            {
                Directory.CreateDirectory(Folder);
                using (FileStream stream = File.Create(FilePath))
                {
                    new XmlSerializer(typeof(ClockSettings)).Serialize(stream, settings);
                }
            }
            catch
            {
                // A read-only profile should not prevent the clock from running.
            }
        }
    }

    internal static class StartupManager
    {
        private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string ValueName = "FloatingClock";

        public static void SetEnabled(bool enabled)
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RunKey, true))
            {
                if (key == null) return;
                if (enabled)
                {
                    key.SetValue(ValueName, "\"" + Application.ExecutablePath + "\"");
                }
                else
                {
                    key.DeleteValue(ValueName, false);
                }
            }
        }

        public static bool IsEnabled()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RunKey, false))
            {
                return key != null && key.GetValue(ValueName) != null;
            }
        }
    }

    public sealed class ClockForm : Form
    {
        private const int WM_NCHITTEST = 0x0084;
        private const int HTCAPTION = 2;
        private const int WM_HOTKEY = 0x0312;
        private const int HotkeyId = 0x4643;
        private const int MOD_ALT = 0x0001;
        private const int MOD_CONTROL = 0x0002;
        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TRANSPARENT = 0x20;
        private const int WS_EX_TOOLWINDOW = 0x80;

        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int modifiers, int virtualKey);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int index);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int index, int newStyle);

        private readonly System.Windows.Forms.Timer timer;
        private readonly NotifyIcon trayIcon;
        private readonly ContextMenuStrip menu;
        private readonly ToolStripMenuItem lockItem;
        private readonly ToolStripMenuItem clickThroughItem;
        private readonly ToolStripMenuItem topMostItem;
        private ClockSettings settings;
        private bool exiting;
        private readonly Icon applicationIcon;

        public ClockForm()
        {
            settings = SettingsStore.Load();
            applicationIcon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            Text = "悬浮时钟";
            Icon = applicationIcon;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            DoubleBuffered = true;
            Padding = new Padding(14, 8, 14, 8);
            MinimumSize = new Size(80, 38);

            menu = new ContextMenuStrip();
            ToolStripMenuItem settingsItem = new ToolStripMenuItem("设置(&S)...", null, delegate { OpenSettings(); });
            lockItem = new ToolStripMenuItem("锁定位置(&L)", null, delegate { ToggleLocked(); });
            clickThroughItem = new ToolStripMenuItem("鼠标穿透(&C)", null, delegate { ToggleClickThrough(); });
            topMostItem = new ToolStripMenuItem("始终置顶(&T)", null, delegate { ToggleTopMost(); });
            ToolStripMenuItem hideItem = new ToolStripMenuItem("隐藏/显示  (Ctrl+Alt+T)", null, delegate { ToggleVisible(); });
            ToolStripMenuItem exitItem = new ToolStripMenuItem("退出(&X)", null, delegate { ExitApplication(); });
            menu.Items.Add(settingsItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(lockItem);
            menu.Items.Add(clickThroughItem);
            menu.Items.Add(topMostItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(hideItem);
            menu.Items.Add(exitItem);
            ContextMenuStrip = menu;

            trayIcon = new NotifyIcon();
            trayIcon.Icon = applicationIcon ?? SystemIcons.Application;
            trayIcon.Text = "悬浮时钟";
            trayIcon.Visible = true;
            trayIcon.ContextMenuStrip = menu;
            trayIcon.DoubleClick += delegate { ToggleVisible(); };

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 200;
            timer.Tick += delegate { RefreshClock(); };

            DoubleClick += delegate { OpenSettings(); };
            MouseUp += OnClockMouseUp;
            Move += delegate
            {
                if (WindowState == FormWindowState.Normal && Visible)
                {
                    settings.PositionX = Left;
                    settings.PositionY = Top;
                }
            };
            FormClosing += OnFormClosing;
            Shown += OnShown;

            ApplySettings(false);
            timer.Start();
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_TOOLWINDOW;
                return cp;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            RegisterHotKey(Handle, HotkeyId, MOD_CONTROL | MOD_ALT, (int)Keys.T);
            ApplyClickThrough();
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            UnregisterHotKey(Handle, HotkeyId);
            base.OnHandleDestroyed(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HotkeyId)
            {
                ToggleVisible();
                return;
            }

            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST && m.Result.ToInt32() == 1 && !settings.Locked)
            {
                m.Result = new IntPtr(HTCAPTION);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            using (Brush brush = new SolidBrush(Color.FromArgb(settings.TextColorArgb)))
            using (StringFormat format = new StringFormat())
            {
                format.Alignment = StringAlignment.Center;
                format.LineAlignment = StringAlignment.Center;
                e.Graphics.DrawString(GetTimeText(), Font, brush, ClientRectangle, format);
            }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            UpdateShape();
        }

        private void OnShown(object sender, EventArgs e)
        {
            SizeToClock();
            if (settings.PositionX >= 0 && settings.PositionY >= 0)
            {
                Rectangle desired = new Rectangle(settings.PositionX, settings.PositionY, Width, Height);
                bool visibleOnScreen = false;
                foreach (Screen screen in Screen.AllScreens)
                {
                    if (screen.WorkingArea.IntersectsWith(desired))
                    {
                        visibleOnScreen = true;
                        break;
                    }
                }
                if (visibleOnScreen)
                {
                    Location = new Point(settings.PositionX, settings.PositionY);
                    return;
                }
            }
            Rectangle area = Screen.PrimaryScreen.WorkingArea;
            Location = new Point(area.Right - Width - 24, area.Top + 24);
        }

        private void RefreshClock()
        {
            Invalidate();
        }

        private string GetTimeText()
        {
            try
            {
                return DateTime.Now.ToString(settings.TimeFormat);
            }
            catch
            {
                return DateTime.Now.ToString("HH:mm:ss");
            }
        }

        private void SizeToClock()
        {
            Size measured = TextRenderer.MeasureText(GetTimeText(), Font,
                new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding);
            ClientSize = new Size(Math.Max(80, measured.Width + Padding.Horizontal),
                                  Math.Max(38, measured.Height + Padding.Vertical));
            UpdateShape();
        }

        private void ApplySettings(bool save)
        {
            FontStyle style = settings.FontBold ? FontStyle.Bold : FontStyle.Regular;
            try
            {
                Font = new Font(settings.FontName, settings.FontSize, style, GraphicsUnit.Point);
            }
            catch
            {
                settings.FontName = "Microsoft YaHei UI";
                Font = new Font(settings.FontName, settings.FontSize, style, GraphicsUnit.Point);
            }

            BackColor = Color.FromArgb(settings.BackgroundColorArgb);
            Opacity = Math.Max(0.2, Math.Min(1.0, settings.OpacityPercent / 100.0));
            TopMost = settings.AlwaysOnTop;
            lockItem.Checked = settings.Locked;
            clickThroughItem.Checked = settings.ClickThrough;
            topMostItem.Checked = settings.AlwaysOnTop;
            ApplyClickThrough();
            SizeToClock();
            Invalidate();
            if (save) SettingsStore.Save(settings);
        }

        private void ApplyClickThrough()
        {
            if (!IsHandleCreated) return;
            int style = GetWindowLong(Handle, GWL_EXSTYLE);
            if (settings.ClickThrough)
                style |= WS_EX_TRANSPARENT;
            else
                style &= ~WS_EX_TRANSPARENT;
            SetWindowLong(Handle, GWL_EXSTYLE, style);
        }

        private void UpdateShape()
        {
            if (!settings.RoundedCorners || Width <= 1 || Height <= 1)
            {
                Region = null;
                return;
            }
            int radius = Math.Min(18, Height / 2);
            using (GraphicsPath path = CreateRoundedRectangle(new Rectangle(0, 0, Width, Height), radius))
            {
                Region = new Region(path);
            }
        }

        private static GraphicsPath CreateRoundedRectangle(Rectangle bounds, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;
            Rectangle arc = new Rectangle(bounds.X, bounds.Y, diameter, diameter);
            path.AddArc(arc, 180, 90);
            arc.X = bounds.Right - diameter;
            path.AddArc(arc, 270, 90);
            arc.Y = bounds.Bottom - diameter;
            path.AddArc(arc, 0, 90);
            arc.X = bounds.Left;
            path.AddArc(arc, 90, 90);
            path.CloseFigure();
            return path;
        }

        private void OnClockMouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                settings.PositionX = Left;
                settings.PositionY = Top;
                SettingsStore.Save(settings);
            }
        }

        private void OpenSettings()
        {
            using (SettingsForm form = new SettingsForm(settings))
            {
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    settings = form.Result;
                    try
                    {
                        StartupManager.SetEnabled(settings.AutoStart);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("无法修改开机启动设置：" + ex.Message, "悬浮时钟",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        settings.AutoStart = StartupManager.IsEnabled();
                    }
                    ApplySettings(true);
                }
            }
        }

        private void ToggleLocked()
        {
            settings.Locked = !settings.Locked;
            ApplySettings(true);
        }

        private void ToggleClickThrough()
        {
            settings.ClickThrough = !settings.ClickThrough;
            ApplySettings(true);
            if (settings.ClickThrough)
            {
                trayIcon.ShowBalloonTip(2500, "已开启鼠标穿透",
                    "使用系统托盘菜单或 Ctrl+Alt+T 管理悬浮时钟。", ToolTipIcon.Info);
            }
        }

        private void ToggleTopMost()
        {
            settings.AlwaysOnTop = !settings.AlwaysOnTop;
            ApplySettings(true);
        }

        private void ToggleVisible()
        {
            if (Visible)
                Hide();
            else
            {
                Show();
                TopMost = settings.AlwaysOnTop;
            }
        }

        private void ExitApplication()
        {
            exiting = true;
            SettingsStore.Save(settings);
            trayIcon.Visible = false;
            Close();
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (!exiting && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                return;
            }
            trayIcon.Visible = false;
            trayIcon.Dispose();
        }
    }

    internal sealed class StableScrollPanel : Panel
    {
        public bool SuppressFocusScrolling { get; set; }

        protected override Point ScrollToControl(Control activeControl)
        {
            if (SuppressFocusScrolling)
                return AutoScrollPosition;
            return base.ScrollToControl(activeControl);
        }
    }

    public sealed class SettingsForm : Form
    {
        private readonly ClockSettings source;
        private Label fontValue;
        private NumericUpDown fontSize;
        private CheckBox bold;
        private Button textColorButton;
        private Button backgroundColorButton;
        private NumericUpDown opacity;
        private ComboBox format;
        private CheckBox topMost;
        private CheckBox locked;
        private CheckBox clickThrough;
        private CheckBox rounded;
        private CheckBox autoStart;
        private string selectedFont;
        private Color selectedTextColor;
        private Color selectedBackgroundColor;

        public ClockSettings Result { get; private set; }

        public SettingsForm(ClockSettings settings)
        {
            source = settings;
            selectedFont = settings.FontName;
            selectedTextColor = Color.FromArgb(settings.TextColorArgb);
            selectedBackgroundColor = Color.FromArgb(settings.BackgroundColorArgb);

            Text = "悬浮时钟设置";
            Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96f, 96f);
            Font = new Font("Microsoft YaHei UI", 9f);
            MinimumSize = new Size(560, 620);
            ClientSize = new Size(720, 760);
            BackColor = Color.FromArgb(248, 248, 248);

            TableLayoutPanel root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Margin = new Padding(0), Padding = new Padding(0) };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(root);

            TableLayoutPanel header = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, RowCount = 2, Padding = new Padding(28, 18, 28, 12), BackColor = Color.White, Margin = new Padding(0) };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            header.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            header.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Label title = new Label { Text = "悬浮时钟设置", Dock = DockStyle.Fill, AutoSize = true, Font = new Font("Microsoft YaHei UI", 15f, FontStyle.Bold), ForeColor = Color.FromArgb(32, 32, 32), Margin = new Padding(0, 0, 0, 4) };
            Label subtitle = new Label { Text = "调整外观与窗口行为，窗口可自由缩放。", Dock = DockStyle.Fill, AutoSize = true, ForeColor = Color.FromArgb(96, 96, 96), Margin = new Padding(0) };
            header.Controls.Add(title, 0, 0);
            header.Controls.Add(subtitle, 0, 1);
            root.Controls.Add(header, 0, 0);

            TableLayoutPanel footer = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, RowCount = 1, Padding = new Padding(28, 14, 28, 14), BackColor = Color.White, Margin = new Padding(0) };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            footer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            FlowLayoutPanel footerButtons = new FlowLayoutPanel { Dock = DockStyle.Right, AutoSize = true, WrapContents = false, FlowDirection = FlowDirection.RightToLeft };
            Button ok = NewDialogButton("确定");
            Button cancel = NewDialogButton("取消");
            cancel.DialogResult = DialogResult.Cancel;
            ok.Click += SaveAndClose;
            footerButtons.Controls.Add(ok);
            footerButtons.Controls.Add(cancel);
            footer.Controls.Add(footerButtons, 0, 0);
            root.Controls.Add(footer, 0, 2);
            AcceptButton = ok;
            CancelButton = cancel;

            StableScrollPanel contentHost = new StableScrollPanel { Dock = DockStyle.Fill, Padding = new Padding(22, 18, 22, 18), AutoScroll = true, BackColor = Color.FromArgb(248, 248, 248), SuppressFocusScrolling = true, Margin = new Padding(0) };
            root.Controls.Add(contentHost, 0, 1);

            TableLayoutPanel content = new TableLayoutPanel { AutoSize = false, ColumnCount = 1, RowCount = 4, Padding = new Padding(0), Anchor = AnchorStyles.Top, Width = 600, Height = 680 };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            for (int i = 0; i < 4; i++) content.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            contentHost.Controls.Add(content);
            EventHandler updateContentWidth = delegate
            {
                int available = Math.Max(300, contentHost.ClientSize.Width - contentHost.Padding.Horizontal - 4);
                content.Width = Math.Min(920, available);
                content.Left = Math.Max(contentHost.Padding.Left, (contentHost.ClientSize.Width - content.Width) / 2);
                content.Top = contentHost.Padding.Top;
                content.PerformLayout();
                Size preferred = content.GetPreferredSize(new Size(content.Width, 0));
                content.Height = Math.Max(1, preferred.Height);
            };
            contentHost.Resize += updateContentWidth;

            TableLayoutPanel appearance = CreateCard("显示外观");
            TableLayoutPanel behavior = CreateCard("窗口行为");
            TableLayoutPanel tips = CreateCard("使用提示");
            content.Controls.Add(appearance, 0, 0);
            content.Controls.Add(behavior, 0, 1);
            content.Controls.Add(tips, 0, 2);

            AddAppearanceRows(appearance, settings);
            AddBehaviorRows(behavior, settings);
            Label tip = new Label { Text = "直接拖动时钟可移动；右键或双击打开菜单；Ctrl+Alt+T 可隐藏/显示。\r\n独占全屏游戏可能覆盖普通置顶窗口，建议使用无边框窗口或窗口化模式。", AutoSize = true, MaximumSize = new Size(0, 0), Dock = DockStyle.Fill, ForeColor = Color.FromArgb(96, 96, 96), Padding = new Padding(16, 10, 16, 12) };
            tips.Controls.Add(tip, 0, 1);
            tips.SetColumnSpan(tip, 3);
            tips.RowCount = 2;
            updateContentWidth(null, EventArgs.Empty);
            Shown += delegate
            {
                ApplyWindows11WindowStyle();
                BeginInvoke((MethodInvoker)delegate
                {
                    contentHost.AutoScrollPosition = Point.Empty;
                    ActiveControl = cancel;
                    BeginInvoke((MethodInvoker)delegate
                    {
                        contentHost.AutoScrollPosition = Point.Empty;
                        contentHost.SuppressFocusScrolling = false;
                    });
                });
            };
        }

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

        private void ApplyWindows11WindowStyle()
        {
            try
            {
                const int DwmwaWindowCornerPreference = 33;
                int round = 2;
                DwmSetWindowAttribute(Handle, DwmwaWindowCornerPreference, ref round, sizeof(int));
            }
            catch
            {
                // Older Windows versions simply keep their native window frame.
            }
        }

        private static TableLayoutPanel CreateCard(string title)
        {
            TableLayoutPanel card = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 3, RowCount = 1, BackColor = Color.White, Margin = new Padding(0, 0, 0, 16), Padding = new Padding(18, 12, 18, 14) };
            card.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118));
            card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            card.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 116));
            Label heading = new Label { Text = title, Dock = DockStyle.Fill, AutoSize = true, Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold), ForeColor = Color.FromArgb(32, 32, 32), Padding = new Padding(0, 0, 0, 8) };
            card.Controls.Add(heading, 0, 0);
            card.SetColumnSpan(heading, 3);
            card.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            return card;
        }

        private void AddAppearanceRows(TableLayoutPanel card, ClockSettings settings)
        {
            fontValue = NewValueLabel(settings.FontName);
            Button chooseFont = NewActionButton("选择字体");
            chooseFont.Click += ChooseFont;
            AddCardRow(card, "字体", fontValue, chooseFont);

            fontSize = new NumericUpDown { Minimum = 8, Maximum = 160, DecimalPlaces = 0, Value = (decimal)Math.Max(8, Math.Min(160, settings.FontSize)), Width = 120, Anchor = AnchorStyles.Left };
            bold = NewCheckBox("粗体", settings.FontBold);
            AddCardRow(card, "字号", fontSize, bold);

            textColorButton = NewColorButton(selectedTextColor);
            Button chooseTextColor = NewActionButton("选择颜色");
            chooseTextColor.Click += delegate { PickColor(true); };
            AddCardRow(card, "文字颜色", textColorButton, chooseTextColor);

            backgroundColorButton = NewColorButton(selectedBackgroundColor);
            Button chooseBackground = NewActionButton("选择颜色");
            chooseBackground.Click += delegate { PickColor(false); };
            AddCardRow(card, "背景颜色", backgroundColorButton, chooseBackground);

            opacity = new NumericUpDown { Minimum = 20, Maximum = 100, Value = settings.OpacityPercent, Increment = 5, Width = 120, Anchor = AnchorStyles.Left };
            Label percent = new Label { Text = "%", AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(8, 5, 0, 0) };
            AddCardRow(card, "窗口透明度", opacity, percent);

            format = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill, IntegralHeight = false, DropDownHeight = 180 };
            format.Items.AddRange(new object[] { "HH:mm:ss", "HH:mm", "yyyy-MM-dd  HH:mm:ss", "MM-dd  HH:mm", "hh:mm:ss tt" });
            int selected = format.Items.IndexOf(settings.TimeFormat);
            format.SelectedIndex = selected >= 0 ? selected : 0;
            AddCardRow(card, "时间格式", format, null);
        }

        private void AddBehaviorRows(TableLayoutPanel card, ClockSettings settings)
        {
            topMost = NewCheckBox("始终置顶", settings.AlwaysOnTop);
            locked = NewCheckBox("锁定窗口位置", settings.Locked);
            clickThrough = NewCheckBox("鼠标穿透（在托盘中管理）", settings.ClickThrough);
            rounded = NewCheckBox("圆角背景", settings.RoundedCorners);
            autoStart = NewCheckBox("登录 Windows 后自动启动", StartupManager.IsEnabled());
            AddCardRow(card, "", topMost, null);
            AddCardRow(card, "", locked, null);
            AddCardRow(card, "", clickThrough, null);
            AddCardRow(card, "", rounded, null);
            AddCardRow(card, "", autoStart, null);
        }

        private static void AddCardRow(TableLayoutPanel card, string label, Control value, Control action)
        {
            int row = card.RowCount++;
            card.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Label caption = new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 7, 12, 5), ForeColor = Color.FromArgb(64, 64, 64) };
            card.Controls.Add(caption, 0, row);
            if (action == null)
            {
                card.Controls.Add(value, 1, row);
                card.SetColumnSpan(value, 2);
            }
            else
            {
                value.Margin = new Padding(0, 3, 6, 3);
                action.Margin = new Padding(4, 2, 0, 2);
                card.Controls.Add(value, 1, row);
                card.Controls.Add(action, 2, row);
            }
        }

        private static CheckBox NewCheckBox(string text, bool value)
        {
            return new CheckBox { Text = text, Checked = value, AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 4, 0, 4), UseCompatibleTextRendering = false };
        }

        private static Label NewValueLabel(string text)
        {
            return new Label { Text = text, AutoEllipsis = true, Dock = DockStyle.Fill, Height = 34, TextAlign = ContentAlignment.MiddleLeft, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(8, 0, 8, 0) };
        }

        private static Button NewColorButton(Color color)
        {
            return new Button { BackColor = color, Dock = DockStyle.Fill, Height = 34, FlatStyle = FlatStyle.Flat, TabStop = false, Margin = new Padding(3), MinimumSize = new Size(110, 32) };
        }

        private static Button NewActionButton(string text)
        {
            return new Button { Text = text, Dock = DockStyle.Fill, Height = 34, MinimumSize = new Size(104, 32), Margin = new Padding(4, 0, 4, 0), Padding = new Padding(0), TextAlign = ContentAlignment.MiddleCenter, UseCompatibleTextRendering = false };
        }

        private static Button NewDialogButton(string text)
        {
            Button button = new Button { Text = text, AutoSize = false, Size = new Size(100, 36), Margin = new Padding(8, 0, 0, 0), Padding = new Padding(0), TextAlign = ContentAlignment.MiddleCenter, UseCompatibleTextRendering = false };
            if (text == "确定")
            {
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderSize = 0;
                button.BackColor = Color.FromArgb(0, 95, 184);
                button.ForeColor = Color.White;
            }
            return button;
        }

        private void ChooseFont(object sender, EventArgs e)
        {
            using (FontDialog dialog = new FontDialog())
            {
                dialog.Font = new Font(selectedFont, (float)fontSize.Value,
                    bold.Checked ? FontStyle.Bold : FontStyle.Regular);
                dialog.ShowEffects = false;
                dialog.MinSize = 8;
                dialog.MaxSize = 160;
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    selectedFont = dialog.Font.FontFamily.Name;
                    fontValue.Text = selectedFont;
                    fontSize.Value = Math.Max(fontSize.Minimum, Math.Min(fontSize.Maximum, (decimal)dialog.Font.Size));
                    bold.Checked = dialog.Font.Bold;
                }
            }
        }

        private void PickColor(bool text)
        {
            using (ColorDialog dialog = new ColorDialog())
            {
                dialog.FullOpen = true;
                dialog.Color = text ? selectedTextColor : selectedBackgroundColor;
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    if (text)
                    {
                        selectedTextColor = dialog.Color;
                        textColorButton.BackColor = dialog.Color;
                    }
                    else
                    {
                        selectedBackgroundColor = dialog.Color;
                        backgroundColorButton.BackColor = dialog.Color;
                    }
                }
            }
        }

        private void SaveAndClose(object sender, EventArgs e)
        {
            Result = new ClockSettings();
            Result.FontName = selectedFont;
            Result.FontSize = (float)fontSize.Value;
            Result.FontBold = bold.Checked;
            Result.TextColorArgb = selectedTextColor.ToArgb();
            Result.BackgroundColorArgb = selectedBackgroundColor.ToArgb();
            Result.OpacityPercent = (int)opacity.Value;
            Result.TimeFormat = format.SelectedItem.ToString();
            Result.AlwaysOnTop = topMost.Checked;
            Result.Locked = locked.Checked;
            Result.ClickThrough = clickThrough.Checked;
            Result.RoundedCorners = rounded.Checked;
            Result.AutoStart = autoStart.Checked;
            Result.PositionX = source.PositionX;
            Result.PositionY = source.PositionY;
            DialogResult = DialogResult.OK;
            Close();
        }
    }

    internal static class Program
    {
        private const string MutexName = @"Local\FloatingClockApp.SingleInstance";
        private static readonly IntPtr DpiAwarenessContextPerMonitorAwareV2 = new IntPtr(-4);

        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();

        [DllImport("user32.dll")]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr value);

        [STAThread]
        private static void Main()
        {
            bool createdNew;
            using (Mutex mutex = new Mutex(true, MutexName, out createdNew))
            {
                if (!createdNew)
                {
                    return;
                }

                try
                {
                    SetProcessDpiAwarenessContext(DpiAwarenessContextPerMonitorAwareV2);
                }
                catch
                {
                    SetProcessDPIAware();
                }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new ClockForm());
                GC.KeepAlive(mutex);
            }
        }
    }
}
